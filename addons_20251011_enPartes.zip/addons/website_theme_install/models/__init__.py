# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ir_module_module
from . import res_company
from . import res_config_settings
from . import theme_models
from . import website
