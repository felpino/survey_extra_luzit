# -*- coding: utf-8 -*-

from . import res_company
from . import res_partner
from . import res_config_settings
from . import snailmail_letter
from . import ir_actions_report
from . import ir_qweb_fields
from . import mail_message
