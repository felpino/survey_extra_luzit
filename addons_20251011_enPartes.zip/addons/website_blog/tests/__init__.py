# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.addons.website_blog.tests import test_ui
from odoo.addons.website_blog.tests import test_website_blog_flow
