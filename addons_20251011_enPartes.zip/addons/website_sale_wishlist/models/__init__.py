# -*- coding: utf-8 -*-
from . import ir_autovacuum
from . import product_wishlist
from . import res_users
