# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import repair_cancel
from . import repair_make_invoice
from . import stock_warn_insufficient_qty
